let a = 9
var b = 27
b == a

let addition = a + b
let subtraction = a - b
let division = a / b
let multiplication = a * b

print; addition
print; subtraction
print; division
print; multiplication
